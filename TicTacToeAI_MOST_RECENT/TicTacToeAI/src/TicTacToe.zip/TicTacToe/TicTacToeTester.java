public class TicTacToeTester
{
   public static void main(String [] args)
   {
      TicTacToe game = new TicTacToe();
      game.showMe();
   }
}
