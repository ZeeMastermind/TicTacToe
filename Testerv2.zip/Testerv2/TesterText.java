public class TesterText
{
   public static void main(String [] args)
   {
      boolean isRunning = true;
      String[] state = {"","","","","","","","",""};
      TicTacToeAIAlternate brain = new TicTacToeAIAlternate();
      int turn = 0;
      
      while (turn < 10)
      {
         
         System.out.print(state[0]);
         System.out.print("|");
         System.out.print(state[1]);
         System.out.print("|");
         System.out.println(state[2]);
         System.out.println("---");
         System.out.print(state[3]);
         System.out.print("|");
         System.out.print(state[4]);
         System.out.print("|");
         System.out.println(state[5]);
         System.out.println("---");
         System.out.print(state[6]);
         System.out.print("|");
         System.out.print(state[7]);
         System.out.print("|");
         System.out.println(state[8]);
         System.out.println();
         
                   
         System.out.print("TURN: ");
         System.out.println(turn);
         if (turn % 2 == 0)
         {
            state[brain.getNextMove(state,turn)] = "X";
         }
         else
         {
            int i = 0;
            for (i = 0; i < 8; i++)
            {
               if (state[i] == "")
               {
                  break;
               }
            }
            state[i] = "O";
         }
            
            
         
         turn++; 
         
      }
      
      
      System.out.println("FINAL STATE:");
      System.out.println();
      System.out.print(state[0]);
      System.out.print("|");
      System.out.print(state[1]);
      System.out.print("|");
      System.out.println(state[2]);
      System.out.println("---");
      System.out.print(state[3]);
      System.out.print("|");
      System.out.print(state[4]);
      System.out.print("|");
      System.out.println(state[5]);
      System.out.println("---");
      System.out.print(state[6]);
      System.out.print("|");
      System.out.print(state[7]);
      System.out.print("|");
      System.out.println(state[8]);
      System.out.println();
   }
}

